const mongoose = require('mongoose');
const UserSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true, index: true },
  passwordHash: String,
  createdAt: { type: Date, default: Date.now },
  integrations: { type: Object, default: {} },
  settings: { type: Object, default: { publicResume: false } }
});
module.exports = mongoose.model('User', UserSchema);
