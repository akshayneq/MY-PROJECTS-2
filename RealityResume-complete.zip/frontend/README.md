Frontend — Next.js + Tailwind

Dev:
```bash
cd frontend
npm install
cp .env.example .env.local
npm run dev
```
The frontend proxies API calls during development to the backend's NEXT_PUBLIC_API_URL.
